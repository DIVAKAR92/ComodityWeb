﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using atplTelecom.DAL;
using atplTelecom.Util;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Default
/// </summary>
namespace atplTelecom.BAL.Common
{
    public class Common : DataAccess
    {
        private bool _isExist;
        private string _sql;
        private string _expression;
        private System.Data.SqlClient.SqlDataReader _reader;
        private bool[] _moduleRights;
        private SqlParameter[] _parms;
        private DataSet _dataSet;

        public Common()
            : base(atplTelecom.Util.Utility.ConnectionString)
        {
            _sql = null;
            _dataSet = new DataSet();
            this._moduleRights = new bool[7];
        }

        public bool[] CheckModuleRights(int ModuleID, int userID)
        {
            try
            {
                this._reader = CheckRights(ModuleID, userID);
                
                while (this._reader.Read())
                {
                    this._moduleRights[0] = Convert.ToBoolean(this._reader["ShowRight"]);
                    this._moduleRights[1] = Convert.ToBoolean(this._reader["AddRight"]);
                    this._moduleRights[2] = Convert.ToBoolean(this._reader["EditRight"]);
                    this._moduleRights[3] = Convert.ToBoolean(this._reader["DeleteRight"]);
                    this._moduleRights[4] = Convert.ToBoolean(this._reader["PrintRight"]);
                    this._moduleRights[5] = Convert.ToBoolean(this._reader["ReconsileRight"]);
                    this._moduleRights[6] = Convert.ToBoolean(this._reader["Submit"]);
                }
                _reader.Close();
                return _moduleRights;
            }
            catch
            {
                throw;
            }
        }

        public System.Data.SqlClient.SqlDataReader CheckRights(int ModuleID, int userID)
        {
            try
            {
                _sql = "CheckModuleRights";
                _parms = new SqlParameter[2];
                _parms[0] = new SqlParameter("@ModuleID", SqlDbType.Int);
                _parms[0].Value = ModuleID;
                _parms[1] = new SqlParameter("@UserID", SqlDbType.Int);
                _parms[1].Value = userID;
                return RunProcedure(_sql, _parms);
            }
            catch
            {
                throw;
            }
        }

    }


}

