using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Collections.Generic;
using System.Web.Security;

public partial class _Default : Page
{
    private System.Data.DataSet _dataSet;
    protected string _errorMessage;

    protected void Page_PreInit(object sender, EventArgs e)
    {
        Theme = "Gray";
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        //_home = new Home();
        _dataSet = new System.Data.DataSet();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.ClientScript.RegisterClientScriptInclude("somescript", ResolveUrl("JS/Common.js"));
        if (!Page.IsPostBack)
        {
            try
            {
                BindData("Oil");
                Draft.Text = "Oil";
            }
            catch (Exception Ex)
            {
                _errorMessage = Ex.Message;
            }
        }
    }

    private void BindData(string itemName)
    {
        try
        {
            Draft.Text = itemName;
            string[] filesindirectory = Directory.GetFiles(Server.MapPath("~/ReportImages/" + itemName));
            List<String> images = new List<string>(filesindirectory.Length);

            foreach (string item in filesindirectory)
            {
                if (System.IO.Path.GetExtension(item) != ".txt")
                {
                    images.Add(String.Format("~/ReportImages/" + itemName + "/{0}", System.IO.Path.GetFileName(item)));
                }
            }
            images.Sort((a, b) => a.CompareTo(b));
            RepeaterImages.DataSource = images;
            RepeaterImages.DataBind();

            string body = string.Empty;
            if (File.Exists(Server.MapPath("~/ReportImages/" + itemName + "/" + itemName + ".txt")))
            {
                divHTML.Attributes.Add("style", "block");
                using (System.IO.StreamReader reader = new System.IO.StreamReader(Server.MapPath("~/ReportImages/" + itemName + "/" + itemName + ".txt")))
                {
                    divHTML.InnerHtml = reader.ReadToEnd();
                }
            }
            else
            {
                divHTML.InnerHtml = "";
                divHTML.Attributes.Add("style", "none");
            }
        }
        catch
        {
            throw;
        }
    }

    public void OpenNewWindow(string url)
    {
        ClientScript.RegisterStartupScript(this.GetType(), "newWindow", String.Format("<script>window.open('{0}');</script>", url));
    }

    protected void HomeLnk_Click(object sender, EventArgs e)
    {
        Response.Redirect(FormsAuthentication.DefaultUrl);
    }
    protected void QuickLinkMenu_MenuItemClick(object sender, MenuEventArgs e)
    {
        BindData(e.Item.Text);
    }
}
