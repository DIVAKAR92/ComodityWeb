﻿var ignoreEvents = false;
imgout=new Image(9,9);
imgin=new Image(9,9);
imgout.src="~/Images/bullet_plus.gif";
imgin.src="~/Images/bullet_minus.gif";

function toggleBox(szDivID, iState) // 1 visible, 0 hidden
{
    if(document.layers)	   //NN4+
    {
       document.layers[szDivID].visibility = iState ? "show" : "hide";
    }
    else if(document.getElementById)	  //gecko(NN6) + IE 5+
    {
        var obj = document.getElementById(szDivID);
        obj.style.visibility = iState ? "visible" : "hidden";
    }
    else if(document.all)	// IE 4
    {
        document.all[szDivID].style.visibility = iState ? "visible" : "hidden";
    }
}
        
function nodeEventHandler(treeview, node, eventType) 
{
    if (ignoreEvents) return;
    ignoreEvents = true;
    if (eventType == "checked") 
    {
        SetChildCheckBox(node, true);
        if (AllSiblingChecked(node)) 
        {
           SetParentCheckBox(node, true);            
        }
    } 
    else if (eventType == "unchecked") 
    {
        SetChildCheckBox(node, false);
    }
    ignoreEvents = false;
}

function SetChildCheckBox(parentNode, value)
{
    var childNodes = parentNode.getChildNodes();
    for(var i = 0; i < childNodes.length; i++) 
    {
        var node = childNodes[i];
        node.setChecked(value);
        SetChildCheckBox(node, value);
    }
}

function SetParentCheckBox(node, value)
{
    var parentNode = node.getParent();
    if (parentNode == null) return;
    parentNode.setChecked(value);
    if (!value || AllSiblingChecked(parentNode))
    {
        SetParentCheckBox(parentNode, value);
    }
}

function AllSiblingChecked(node)
{
    var nodes = node.getSiblingNodes();
    for(var i = 0; i < nodes.length; i++) 
    {
        if (!nodes[i].getChecked())
        {
            return false;
        }
    }
    return true;
}

function filter(imagename,objectsrc)
{
	if (document.images)
	{
		document.images[imagename].src=eval(objectsrc+".src");
	}
}


function setSection(id) 
{ 
	if (document.getElementById) 
	{
		if (document.getElementById(id).style.display == "none")
		{
			document.getElementById(id).style.display = 'block';
			filter(("img"+id),'imgin');			
		} 
		else 
		{
			filter(("img"+id),'imgout');
			document.getElementById(id).style.display = 'none';			
		}	
	} 
	else 
	{ 
		if (document.layers) 
		{	
			if (document.id.display == "none")
			{
				document.id.display = 'block';
				filter(("img"+id),'imgin');
			} 
			else 
			{
				filter(("img"+id),'imgout');	
				document.id.display = 'none';
			}
		} 
		else 
		{
			if (document.all.id.style.visibility == "none")
			{
				document.all.id.style.display = 'block';
			}
			else 
			{
				filter(("img"+id),'imgout');
				document.all.id.style.display = 'none';
			}
		}
	}
}

function PreviewImage(obj)
{
    document.all(obj).src=event.srcElement.value;
}

function setSize(height,width)
{
    self.resizeTo(height,width)
}

function popupWindow(url,height,width) 
{ 
    window.open(url,'_blank','toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=1,resizable=1,width='+width+',height='+height+',left=0,top=0'); 
} 


function SelectCheckBox(parentBox,childBox) 
{
    var frm = document.forms[0];
    // Loop through all elements
    for (i=0; i<frm.length; i++) 
    {    
        var ControlName = frm.elements[i].name;
        if(ControlName.indexOf(parentBox)>0)
        {
            if(document.all(ControlName).checked)
            {
                for(i=0; i<frm.length; i++)
                {
                    var ChildControlName = frm.elements[i].name;
                    if(ChildControlName.indexOf(childBox)>0)
                    {
                        document.all(ChildControlName).checked=true;
                    }
                }
            }
            if(!document.all(ControlName).checked)
            {
                for(i=0; i<frm.length; i++)
                {
                    var ChildControlName = frm.elements[i].name;
                    if(ChildControlName.indexOf(childBox)>0)
                    {
                        document.all(ChildControlName).checked=false;
                    }
                }
            }
        }
    }

    var boolchk=true;
    for (i=0; i<frm.length; i++)
    {
        var ChildControlName = frm.elements[i].name;
        if(ChildControlName.indexOf(childBox)>0)
        {
            if(document.all(ChildControlName).checked)
            {
                boolchk=true;
            }
            else
            {
                boolchk=false;
                return;
            }
        }
    }
}   

function PopWindow(target,textControl,valueControl,typeID)
{
    text=document.getElementById(textControl).id;
    value=document.getElementById(valueControl).id;
    var url=target+"CommonPopup.aspx?Type="+typeID+"&TextControl="+text+"&ValueControl="+value;
    window.open(url,'anycontent','toolbar=0,directories=0,status=0,menubar=0,scrollbars=1,resizable=0,width=500,height=450');
}

function ClearData(textControl)		
{	
	if(document.getElementById(textControl).value!="")
	{							
		document.getElementById(textControl).value="";
	}			
}
